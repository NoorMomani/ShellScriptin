#!/bin/bash

total_files=0
total_size=0

Date=`date +%D`;
echo -e "\n=================================\nWelcome back Noor.   $Date\n================================="

get_command_help() {
    echo "Usage: ./shell.sh [options] <directory_paths>"
    echo "Options:"
    echo "  -e <extensions>   Specify file extensions to search for (separated by commas)"
    echo "  -s <size>         Filter files by size (e.g., +1M, -500K)"
    echo "  -p <permissions>  Filter files by permissions (e.g., 644, +x)"
    echo "  -m <timestamp>    Filter files by last modified timestamp (e.g., +7d, -1w)"
    echo "  -h                Help"
    echo "  -n                generation of an additional report file named total_found_files.txt"
}

function get_file_details() {
  file="$1"
  file_size=$(stat -c "%s" "$file")
  owner=$(ls -l "$file" | awk '{print $3}')
  permissions=$(ls -l "$file" | awk '{print $1}')
  last_edit=$(stat -c "%y" "$file")
  echo "File: $file"
  echo "Size: $file_size"
  echo "Owner: $owner"
  echo "Permissions: $permissions"
  echo "Last Edit: $last_edit"
}

function get_find_report() {
    directory_path="$1"
    total_files_report=$2
    total_size_report=$3

    file_list=$(find $directory_path -type f -perm $permissions -mtime $last_modified -size $size | egrep  ".$(echo "$extension" | sed 's/,/|./g')")
    # Check if any files are found
    if [ -z "$file_list" ]; then
      echo "No files with the specified option found in the directory: $directory_path"
    else
      echo "--------------------------------------------------" >> "$report_file"
      echo "Directory: $directory_path" >> "$report_file"

      # Loop through each file in the directory and get details
      while IFS= read -r file; do
        echo "--------------------------------------------------" >> "$report_file"
        get_file_details "$file" >> "$report_file"
        total_files_report=$((total_files_report+1))
      done <<< "$file_list"

      echo "--------------------------------------------------" >> "$report_file"
      echo "----- Files Grouped by Owner and Sorted by Size -----" >> "$report_file"

      # Get unique owners and their file sizes
      owners=$(echo "$file_list" | xargs -I {} ls -l {} | awk '{print $3}' | sort | uniq)
      for owner in $owners; do
        owner_files=$(echo "$file_list" | xargs -I {} ls -l {} | awk -v owner="$owner" '$3==owner {print $5, $9}')
        owner_total_size=$(echo "$owner_files" | awk '{sum+=$1} END {print sum}')
        echo "Owner: $owner" >> "$report_file"
        echo "Total Size: $owner_total_size" >> "$report_file"
        echo "$owner_files" | sort -rn >> "$report_file"
        echo "--------------------------------------------------" >> "$report_file"
        ((total_size_report+=owner_total_size))
        total_files=$total_files_report
        total_size=$total_size_report
      done
    fi
}

size=-10M
extension="*"
permissions="-777"
last_modified="-7"
generate_report=false

while getopts "ne:p:m:s:h" opt; do
  case $opt in
    h)
      get_command_help
      exit 0
      ;;
    s)
      size=${OPTARG:-10M}
      ;;
    e)
      extension="${OPTARG:-*}"
      ;;
    p)
      permissions="${OPTARG:-777}"
      ;;
    m)
      last_modified="${OPTARG:-7}"
      ;;
    n)
      generate_report=true
      ;;
    \?)
      echo "Invalid option"
      get_command_help
      exit 0
      ;;
  esac
done
shift "$(($OPTIND -1))"

# Check if directory path arguments are provided
if [ $# -eq 0 ]; then
  echo "Please provide at least one directory path as an argument."
  get_command_help
  exit 1
fi

report_file="file_analysis.txt"
$(rm $report_file)

# Generate the report
echo "----- File Analysis Report -----" > "$report_file"

# Check if only one argument is provided
if [ $# -eq 1 ]; then
  directory_path="$1"

  # Find all files with specified extensions in the directory
  get_find_report "$directory_path" "$total_files" "$total_size"

else
  # Loop through each directory path
  for directory_path in "$@"; do

    # Find all files with specified extensions in the directory and subdirectories
    get_find_report "$directory_path" "$total_files" "$total_size"
  done
fi

echo "Report generated successfully. Please check $report_file."

if [ $generate_report ]; then
  second_report="total_found_files.txt"
  rm $second_report
  echo "total # of files: $total_files" >> "$second_report"
  echo "total size of files: $total_size" >> "$second_report"
  exit 0
fi